# Test Cases — Skill Gap Analyzer
> LearnDepth Track 1 | Project #58 | Anik Sarkar

---

## Test Case #1 — Valid Resume File + Valid JD File

**CLI Mode:** Mode 1 (file inputs)

**Command:**
```bash
uv run python src/main.py --resume data/resume.txt --jd data/job_description.txt
```

**Input:**
- Resume: `data/resume.txt` (Michael Carter, skills: Java, Git, Docker, 3 years exp)
- JD: `data/job_description.txt` (Senior Backend Engineer, requires: Spring Boot, PostgreSQL, REST APIs)

**Expected Output:**
- Matched skills listed with ✅
- Missing skills listed with correct priority (CRITICAL / IMPORTANT / NICE-TO-HAVE)
- Experience gap calculated correctly
- Verdict: "Partial fit — missing 2 critical skill(s)."
- JSON report saved to `output/`

**Result:** ✅ Pass

---

## Test Case #2 — Skills Typed Manually via --skills Flag

**CLI Mode:** Mode 2 (manual skills input)

**Command:**
```bash
uv run python src/main.py --skills "Java, Git, Python" --jd data/job_description.txt
```

**Input:**
- Skills typed: Java, Git, Python
- JD: `data/job_description.txt`

**Expected Output:**
- Candidate name shown as "Unknown" (no resume file, no name extractable)
- Matched skills: Java, Git
- Missing skills ranked by priority
- Report saved and printed correctly

**Result:** ✅ Pass

---

## Test Case #3 — JD File Not Found

**CLI Mode:** Mode 1

**Command:**
```bash
uv run python src/main.py --resume data/resume.txt --jd data/wrong_path.txt
```

**Input:**
- JD path: `data/wrong_path.txt` (does not exist)

**Expected Output:**
```
Error: File not found: data/wrong_path.txt
```
- Program exits cleanly, no crash, no traceback shown to user

**Result:** ✅ Pass

---

## Test Case #4 — Interactive Mode (No Flags)

**CLI Mode:** Mode 3 (fully interactive)

**Command:**
```bash
uv run python src/main.py
```

**Interaction:**
```
Enter path to JD file: data/job_description.txt
Enter resume file path OR type your skills manually: Java, Git, Docker
```

**Expected Output:**
- Same quality output as Mode 1/2
- Correctly handles both path input and manual skill input at the prompt

**Result:** ✅ Pass

---

## Test Case #5 — Candidate Matches All Required Skills

**CLI Mode:** Mode 2

**Command:**
```bash
uv run python src/main.py --skills "Spring Boot, PostgreSQL, REST APIs, Docker, Git, Java" --jd data/job_description.txt
```

**Input:**
- Skills cover all required skills in the JD

**Expected Output:**
- All required skills appear under Matched Skills ✅
- Only NICE-TO-HAVE gaps remain (preferred skills not provided)
- Verdict: "Good fit — only minor gaps."

**Result:** ✅ Pass

---

## Test Case #6 — Resume File Not Found

**CLI Mode:** Mode 1

**Command:**
```bash
uv run python src/main.py --resume data/fake_resume.pdf --jd data/job_description.txt
```

**Input:**
- Resume path: `data/fake_resume.pdf` (does not exist)

**Expected Output:**
```
Error: File not found: data/fake_resume.pdf
```
- Program exits cleanly with no crash

**Result:** ✅ Pass

---

## Test Case #7 — Good Fit (No Critical Gaps, Minor Gaps Remain)

**CLI Mode:** Mode 2

**Command:**
```bash
uv run python src/main.py --skills "Spring Boot, PostgreSQL, REST APIs, Docker, Git, Java" --jd data/job_description.txt
```

**Input:**
- Candidate has all required skills but none of the preferred skills (AWS, Kubernetes, Redis, Kafka)

**Expected Output:**
- All required skills matched ✅
- 4 NICE-TO-HAVE gaps (AWS, Kubernetes, Redis, Kafka)
- No CRITICAL or IMPORTANT gaps
- Verdict: `Good fit — only minor gaps.`

**Result:** ✅ Pass

---

## Test Case #8 — Strong Fit (Zero Gaps)

**CLI Mode:** Mode 2

**Command:**
```bash
uv run python src/main.py --skills "Spring Boot, PostgreSQL, REST APIs, Docker, Git, Java, AWS, Kubernetes, Redis, Kafka" --jd data/job_description.txt
```

**Input:**
- Candidate has every required AND preferred skill from the JD

**Expected Output:**
- All skills matched ✅
- Missing Skills section: empty
- Verdict: `Strong fit — no skill gaps found.`

**Result:** ✅ Pass

---

## Summary

| # | Test | CLI Mode | Result |
|---|---|---|---|
| 1 | Valid resume + valid JD | Mode 1 (files) | ✅ Pass |
| 2 | Manual skills + JD file | Mode 2 (--skills) | ✅ Pass |
| 3 | JD file not found | Mode 1 | ✅ Pass |
| 4 | Fully interactive, no flags | Mode 3 (interactive) | ✅ Pass |
| 5 | Candidate matches all required skills | Mode 2 | ✅ Pass |
| 6 | Resume file not found | Mode 1 | ✅ Pass |
| 7 | Good fit — no critical gaps, minor gaps remain | Mode 2 | ✅ Pass |
| 8 | Strong fit — zero gaps, all skills matched | Mode 2 | ✅ Pass |
